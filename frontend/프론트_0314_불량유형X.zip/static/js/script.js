let unreadCount = 0;
let unreadMessages = [];
let unreadNotificationVisible = false;
let lastReadTime = Date.now(); // 마지막으로 알림을 확인한 시간

// 로그아웃 기능
function logout() {
    if (confirm('로그아웃 하시겠습니까?')) {
        window.location.href = '/logout'; // 로그아웃 페이지로 이동
    }
}

// 사이드바 메뉴 클릭 시 해당 페이지로 이동
document.querySelectorAll('.nav-item > a').forEach(item => {
    item.addEventListener('click', function (e) {
        e.preventDefault();
        const targetPage = this.href.split('/').pop(); // URL에서 마지막 경로 추출
        window.location.href = targetPage;
    });
});

// 알림 토글 (알림 드롭다운 표시/숨기기)
function toggleNotificationDropdown() {
    let dropdown = document.getElementById("notificationDropdown");
    dropdown.classList.toggle("hidden");
    dropdown.style.display = dropdown.classList.contains("hidden") ? "none" : "block";
}

// 드롭다운 외부 클릭 시 닫기
document.addEventListener("click", function (event) {
    let dropdown = document.getElementById("notificationDropdown");
    let icon = document.querySelector(".notification-icon");

    if (!dropdown.contains(event.target) && !icon.contains(event.target)) {
        dropdown.classList.add("hidden");
        dropdown.style.display = "none";
    }
});

// 파일 선택 시 파일명 표시
function showFileName() {
    const fileInput = document.getElementById('file-upload');
    const fileName = document.getElementById('fileName');
    fileName.textContent = fileInput.files.length > 0 ? fileInput.files[0].name : '선택된 파일 없음';
}

// 탭 전환 (탭 클릭 시 해당 컨텐츠만 표시)
function showTab(tabId) {
    document.querySelectorAll('.tab-content').forEach(content => content.style.display = 'none');
    document.getElementById(tabId).style.display = 'block';

    document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
    event.target.classList.add('active');
}

// 폼 초기화
function resetForm() {
    document.querySelectorAll('input[type="text"], textarea').forEach(input => input.value = '');
    document.querySelectorAll('input[type="radio"]').forEach(radio => radio.checked = false);
    document.getElementById('fileName').textContent = '선택된 파일 없음';
}

// 서브메뉴 토글 기능 (하위 메뉴 표시/숨김)
document.querySelectorAll('.submenu-toggle').forEach(toggle => {
    toggle.addEventListener('click', function (e) {
        e.preventDefault();
        const submenu = this.parentElement.nextElementSibling;
        submenu.classList.toggle('closed');
        this.classList.toggle('fa-chevron-down');
        this.classList.toggle('fa-chevron-right');
    });
});

// 읽지 않은 메시지 개수 업데이트
function updateUnreadAnomalyCount() {
    const countElement = document.getElementById("unreadAnomalyCount");
    countElement.textContent = unreadCount > 0 ? unreadCount : "";
    countElement.classList.toggle("hidden", unreadCount === 0);
}

// "안 읽은 메시지 N건" 표시 (N만 증가)
function showUnreadMessageNotification() {
    const container = document.getElementById("anomalyAlertContainer");
    let existingNotification = document.querySelector(".unread-message-notification");

    if (existingNotification) {
        // 기존 "N건 메시지"가 있으면 개수만 업데이트
        existingNotification.querySelector("span").textContent = `⚠ 안 읽은 메시지 ${unreadCount}건이 있습니다.`;
    } else {
        // 처음으로 "N건 메시지" 표시
        container.innerHTML = `
            <div class="anomaly-alert unread-message-notification">
                <span>⚠ 안 읽은 메시지 ${unreadCount}건이 있습니다.</span>
                <button class="confirm-btn" onclick="markUnreadMessagesAsRead()">확인</button>
            </div>
        `;
    }
    unreadNotificationVisible = true;
}

// 1분 동안 확인하지 않으면 "안 읽은 메시지 N건" 표시
function checkUnreadMessages() {
    setInterval(() => {
        let elapsedTime = Date.now() - lastReadTime;
        if (elapsedTime >= 60000 && unreadMessages.length > 0 && !unreadNotificationVisible) {
            showUnreadMessageNotification();
        }
    }, 10000); // 10초마다 체크
}

// 이상 알림 추가 (N건 증가만 적용)
function addAnomalyAlert(message) {
    if (unreadNotificationVisible) {
        // "N건 메시지"가 보일 때는 숫자만 증가
        unreadMessages.push(message);
        unreadCount++;
        updateUnreadAnomalyCount();
        showUnreadMessageNotification();
    } else {
        // 개별 이상 알림 표시
        const container = document.getElementById("anomalyAlertContainer");
        container.innerHTML = `
            <div class="anomaly-alert">
                <span>${message}</span>
                <button class="confirm-btn" onclick="markAnomalyAsRead(this, '${message}')">확인</button>
            </div>
        `;
        unreadMessages.push(message);
        unreadCount++;
        updateUnreadAnomalyCount();
        checkUnreadMessages(); // 1분 체크 시작
    }
}

// "안 읽은 메시지 N건"에서 확인 버튼을 눌렀을 때 동작
function markUnreadMessagesAsRead() {
    lastReadTime = Date.now();
    unreadNotificationVisible = false;
    unreadMessages = [];
    unreadCount = 0;
    updateUnreadAnomalyCount();

    // N건 메시지를 제거하고, 다시 개별 알림을 보이게 함
    document.getElementById("anomalyAlertContainer").innerHTML = "";
}

// 개별 이상 알림에서 확인 버튼을 눌렀을 때
function markAnomalyAsRead(button, message) {
    button.parentElement.remove();
    lastReadTime = Date.now();
    unreadNotificationVisible = false;

    unreadMessages = unreadMessages.filter(msg => msg !== message);
    unreadCount = unreadMessages.length;
    updateUnreadAnomalyCount();
    saveNotifications();

    checkUnreadMessages();
}

// 알림 저장 (localStorage 활용)
function saveNotifications() {
    localStorage.setItem("notifications", JSON.stringify(unreadMessages));
    localStorage.setItem("unreadCount", unreadCount);
}

// 페이지 로드 시 알림 복원
document.addEventListener("DOMContentLoaded", () => {
    let storedNotifications = localStorage.getItem("notifications");
    let storedUnreadCount = localStorage.getItem("unreadCount");

    if (storedNotifications) {
        unreadMessages = JSON.parse(storedNotifications);
        unreadCount = parseInt(storedUnreadCount) || 0;
        updateUnreadAnomalyCount();
    }
});

// 5초마다 랜덤 메시지 생성 (테스트용)
setInterval(() => {
    let lines = ["A", "B", "C", "D"];
    let issues = ["불량 발생", "이상 동작 감지", "온도 이상 감지", "기계 오작동 감지", "압력 이상 감지"];

    let randomLine = lines[Math.floor(Math.random() * lines.length)];
    let randomIssue = issues[Math.floor(Math.random() * issues.length)];

    let randomMessage = `⚠ 라인 ${randomLine}에서 ${randomIssue}!`;
    addAnomalyAlert(randomMessage);
}, 5000);
